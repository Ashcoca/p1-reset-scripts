package com.galvanize.crudSample.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class EmployeeTest {

    @Test
    public void testThatBaseConstructorWorks() {
        //arrange
        String name = "Fred";
        int age = 30;
        double salary = 30000.0;
        //act
        Employee e = new Employee(name, age, salary);
        //assert
        assertEquals(name, e.getName());
        assertEquals(age, e.getAge());
        assertEquals(salary, e.getSalary());
        assertNotEquals(0, e.getId());
    }

    @Test
    public void testThatSettersWork() {
        //arrange
        String name = "Fred";
        int age = 30;
        double salary = 30000.0;
        //act
        Employee e = new Employee();
        e.setAge(age);
        e.setName(name);
        e.setSalary(salary);
        //assert
        assertEquals(name, e.getName());
        assertEquals(age, e.getAge());
        assertEquals(salary, e.getSalary());
    }

    @Test
    public void testThatNoArgConstructorWorks() {
        //arrange
        //act
        Employee e = new Employee();
        //assert
        assertNull( e.getName());
        assertEquals(0, e.getAge());
        assertEquals(0.0, e.getSalary(), 0.01);
        assertNotEquals(0, e.getId());
    }

    @Test
    public void testGeneratedMethods() {
        //arrange
        String expected = "Employee{id=1, name='Bob', age=25, salary=25000.0}";
        long expectedHash = 1152308667;
        //act
        Employee e = Employee.SAMPLE_EMPLOYEE;
        Employee e2 = new Employee();
        //assert
        assertEquals(expected, e.toString());
        assertEquals(expectedHash, e.hashCode());
        assertFalse(e.equals(e2));
    }
}
