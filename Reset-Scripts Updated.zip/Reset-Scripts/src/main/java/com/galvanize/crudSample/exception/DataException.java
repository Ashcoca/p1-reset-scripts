package com.galvanize.crudSample.exception;

public class DataException extends Exception{

    public DataException() {
        super("Data Exception");
    }

    public DataException(String message) {
        super("Data Exception: " + message);
    }

}
