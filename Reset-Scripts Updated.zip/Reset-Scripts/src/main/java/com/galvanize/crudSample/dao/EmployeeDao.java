package com.galvanize.crudSample.dao;

import com.galvanize.crudSample.domain.Employee;
import com.galvanize.crudSample.exception.DataException;

import java.util.List;

public interface EmployeeDao {
    public Employee getEmployee(long id);
    public List<Employee> getEmployeeByName(String name);
    public List<Employee> getAllEmployees();
    public void updateEmployee(Employee e) throws DataException;
    public void deleteEmployee(Employee e) throws DataException;
    public void addEmployee(Employee e) throws DataException;
}
