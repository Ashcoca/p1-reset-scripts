#!/bin/bash

token=QWMfpLfi3Bs9LHBCtUrm

for ((i=285;i<=314;i++)); do
curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/repository/merged_branches?private_token=${token}";
curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/repository/branches/feature%2Fadd-manager?private_token=${token}";

done

echo -e "\nRemoved Branches: 1-30\n"

for ((i=452;i<=480;i++)); do
curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/repository/merged_branches?private_token=${token}";
curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/repository/branches/feature%2Fadd-manager?private_token=${token}";

done

echo -e "\nRemoved Branches: 31-59\n"

# curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/310/repository/branches/feature%2Fadd-manager?private_token=QWMfpLfi3Bs9LHBCtUrm"

# curl --request POST --form token=QWMfpLfi3Bs9LHBCtUrm --form ref=master "https://code.il2.dso.mil/api/v4/projects/310/trigger/pipeline"

# curl "https://code.il2.dso.mil/api/v4/projects/310/pipeline_schedules?private_token=QWMfpLfi3Bs9LHBCtUrm"

# curl --request POST --form description="Build packages" --form ref="master" --form cron="0 12 * * 0" --form cron_timezone="America/Los_Angeles" --form active="true" "https://code.il2.dso.mil/api/v4/projects/310/pipeline_schedules?private_token=QWMfpLfi3Bs9LHBCtUrm"

