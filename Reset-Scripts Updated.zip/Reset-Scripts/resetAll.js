const simpleGit = require("simple-git");
const git = simpleGit();

console.log('Preparing to reset master...');

const commitArr = [
  "filler",
  "f75795609cbcbe850a15f70c93fc0484d93520fe",
  "f144785bbb5e962542755750fb28f7d39c8acdba",
  "c857f1efa34517d8e40326091a4dbf05dd05df90",
  "5fa15c46693dc55955fff9b509f787e88f7b168c",
  "5c0837c2e45111b2defed4fb9124f6eb11202c22", // 5
  "15aff2276ad22a07ca692cd3eb061cf9443e33ec",
  "14ebd5bc72d1fac5ab0adc72956449e54acd1a54",
  "6bebfb9739203db14310298e4e53c65586ee5d35",
  "9dcb4de83c3d04f78106c28611d57775ea4fb9f1",
  "74d0dfb57dc391bb6e71c5c1c485ef6255f651db", // 10
  "1a739382b07e87ed85a67ef6959bab2c255014db",
  "d776c17ebe732973f9b1fb967bd1cb7272aa4c84",
  "233a82263411a5c122311e319bf1fd7a0264a42f",
  "e969fd25927f8d25305943ea414738435115983b",
  "5622c8c57db41599e62e5719045d4ce0f7dce4ff", // 15
  "661e081a4ed57754fefb73bdb18eb8b03ca5548b",
  "fc83714b6eb3db6057fbc1b826efeee5af2f81a0",
  "66b41f66b6301ffd526d96edf534fb60a97b77e1",
  "48f76ad8baae566c990767711ede99e48f5d7a5d",
  "d24352dbdc2c43e34eb225b1fcb759fdf7257dd9", // 20
  "18cd256dc02669ef8c5a57dd8c15028241803b1c",
  "38da089b33568680c4eba9b38dd766b048bc6deb",
  "b3b6679c99112de721c29b4db665d278d306237a",
  "ede190d1dc07094415f5fa24d0f5ec3324c05a99",
  "a20af709a8d6da8ef086eb4f3faba22c1a90b575", // 25
  "d55541de1d2f139f84738fde87f58e3f87993f95",
  "775d923c22ea17d141aefbf15d88985dc28cc5fc",
  "ad2b268af84cb1cddcfab3401b9a75d16b4b70fc",
  "3426bea4fe49ba2ac02b2875f3df96ceb642f9ed",
  "85ad4b901905820e0c9d08e526adcf67d9c3791b", // 30
  "6a65431ddfd05f08c53faa112a70193b6019e913",
  "45e5236d31b54968630151f4b5893008cd6d48a7",
  "6c0962094a2d0e3a8e958f39cd9bb70e9e47f7ef",
  "4591396aef38c798c40bbe2ea6dcdf4308118f7b",
  "82eb3cafb220682dfbf8129d56b3cf46c3308ac1", // 35
  "5bd358003494753f2b582dab678438d8cfd29072",
  "6235d9acf9531a113579b7afee6a7fc95d6aa4fe",
  "ad5b4047ed7551ebbdeacffc259683d7ef1b7996",
  "10d073fc9732736654a2240c1cf84e37d619de68",
  "23f23cb470b7cd0019e56169a15e00ddd200752a", // 40
  "5031c3cded887d238e640f7bc86dd02a4a2f2989",
  "3db56951847860c89375ed30368da44a8705db5d",
  "6a73e311baa67e452867397a23c424013d8f3430",
  "7f371e74b40442cdd5e87542fc134d76c072ac6a",
  "b8bda9e7086c5ad97e4e198174622599c3853711", // 45
  "a313664e907f1d3b6953e2c8a38dccd6a6ec0a2c",
  "ff9bc737a8d63b7efdde5aa97c1599f141ad3548",
  "55e4fe19445a6210757cc5bff62354b92e4b859e",
  "0000c890edcb68b2fc1d96b18a0ed5f6aa808046",
  "6c45e3176ff16ee3a9fa6fac3fbf775c5fd76f45", // 50
  "cc5aebb112e95ffcfd969ab302c310c32767fb6b",
  "dbd793422c19d3a9f50fa7c90ae45f831b15b391",
  "b8b3e0ccfceb501b72a54dbb73fd1214ffb07824",
  "8542faad47ee08796860d7bb9d2ac165b028e1d6",
  "7ffe32fe6ee18b78a9efbceaf6122162465ab53c", // 55
  "44abd4ad26c52c805614706ea6e038ad5d5555e7",
  "c4542b53556257c21d72ad0117e2cf3ba899b468",
  "99feea9f7e83bbd46bb52c24baf8e01060839bdb",
  "f7dc9aef3821e4a665679dd214409cca0668bba8",
  "d9150d573c6553f7cf9b648a4823e3b89778bcb5"
]


async function reset() {
  for (let i = 1; i <= 59; i++) {
  await git.init()
  .then(() => console.log(`Resetting repo # ${i}`))
  .then(() => git.removeRemote('origin'))
  .then(() => console.log("origin removed"))
  .then(() => git.addRemote('origin', `https://code.il2.dso.mil/tron/products/workshops/workshop-apps/p1-workshop-java-${i < 10 ? `0${i}` : i}`))
  .then(() => console.log("origin added"))
  .then(() => git.fetch('origin', 'master'))
  .then(() => console.log("fetched"))
  .then(() => git.checkout('master'))
  .then(() => console.log("checked out master"))
  .then(() => git.raw(['reset', '--hard', commitArr[i]]))
  .then(() => console.log(`reset to ${commitArr[i]}`))
  .then(() => git.raw(['push', '--force', 'origin', 'HEAD',]))
  .then(() => console.log(`Workshop # ${i} updated`))
  .catch(err => console.error(err))
  }
}

reset();
