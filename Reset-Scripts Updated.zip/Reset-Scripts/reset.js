#! /usr/bin/env node

console.log('Hello CLI');
