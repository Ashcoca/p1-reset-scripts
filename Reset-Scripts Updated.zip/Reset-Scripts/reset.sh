#!/bin/bash

echo "BEGINNING RESET PROCESS..."
./resetUnprotect.sh
echo -e "\nSTEP 1: COMPLETE - BRANCHES UNPROTECTED\n"
node resetAll.js
echo -e "\nSTEP 2: COMPLETE - MASTER BRANCH RESET\n"
node resetEmp.js
echo -e "\nSTEP 3: COMPLETE - EMPLOYEE2 BRANCH RESET\n"
./resetBranches.sh
node resetBranchExp.js
echo -e "\nSTEP 4: COMPLETE - DELETED OTHER BRANCHES\n"
./resetProtect.sh
echo -e "\nSTEP 5: COMPLETE - BRANCHES PROTECTED\n"
echo -e "\nCOMPLETE: ALL REPOS READY\n"
