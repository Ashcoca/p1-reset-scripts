#!/bin/bash

token=QWMfpLfi3Bs9LHBCtUrm

for ((i=285;i<=314;i++)); do
# # curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/master?private_token=${token}";
# # curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/employee2?private_token=${token}";
# # curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/feature%2F%2A?private_token=${token}";
# # curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/feature%2Fadd-manager?private_token=${token}";
curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/%2A?private_token=${token}";
done

echo -e "Unprotected 1-30\n"

for ((i=452;i<=480;i++)); do
# curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/master?private_token=${token}";
# curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/employee2?private_token=${token}";
# curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/feature%2F%2A?private_token=${token}";
# curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/feature%2Fadd-manager?private_token=${token}";
curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/%2A?private_token=${token}";
done

echo -e "Unprotected 30-59\n"

# curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/464/repository/branches/feature%2Fadd-manager?private_token=QWMfpLfi3Bs9LHBCtUrm"
