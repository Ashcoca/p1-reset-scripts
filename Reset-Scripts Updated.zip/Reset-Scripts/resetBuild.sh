#!/bin/bash

token=QWMfpLfi3Bs9LHBCtUrm

for ((i=285;i<=314;i++)); do
curl --request POST --form description="Build packages" --form ref="master" --form cron="0 13 * * 0" --form cron_timezone="America/Los_Angeles" --form active="true" "https://code.il2.dso.mil/api/v4/projects/${i}/pipeline_schedules?private_token=${token}"
curl --request POST --form description="Build packages" --form ref="employee2" --form cron="0 14 * * 0" --form cron_timezone="America/Los_Angeles" --form active="true" "https://code.il2.dso.mil/api/v4/projects/${i}/pipeline_schedules?private_token=${token}"

done

echo -e "\nScheduled Builds\nRepositories 1-30\n"

for ((i=452;i<=480;i++)); do
curl --request POST --form description="Build packages" --form ref="master" --form cron="0 13 * * 0" --form cron_timezone="America/Los_Angeles" --form active="true" "https://code.il2.dso.mil/api/v4/projects/${i}/pipeline_schedules?private_token=${token}"
curl --request POST --form description="Build packages" --form ref="employee2" --form cron="0 14 * * 0" --form cron_timezone="America/Los_Angeles" --form active="true" "https://code.il2.dso.mil/api/v4/projects/${i}/pipeline_schedules?private_token=${token}"
done

echo -e "\nScheduled Builds\nRepositories 30-59\n"
