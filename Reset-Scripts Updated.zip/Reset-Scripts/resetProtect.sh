#!/bin/bash

token=QWMfpLfi3Bs9LHBCtUrm

for ((i=285;i<=314;i++)); do
curl --request POST "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches?private_token=${token}&name=%2A&push_access_level=30&merge_access_level=30&unprotect_access_level=30";
done

echo -e "\nProtected 1-30\n"

for ((i=452;i<=480;i++)); do
curl --request POST "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches?private_token=${token}&name=%2A&push_access_level=30&merge_access_level=30&unprotect_access_level=30";
done

echo -e "\nProtected 31-59\n"
