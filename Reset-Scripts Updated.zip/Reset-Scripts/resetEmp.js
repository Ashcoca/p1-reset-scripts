const simpleGit = require("simple-git");
const fs = require('fs');

const git = simpleGit();

const oldPath = 'EmployeeDaoMapImpl.java';
const newPath = 'src/main/java/com/galvanize/crudSample/dao/implementation/EmployeeDaoMapImpl.java';
const oldPath2 = 'Employee.java';
const newPath2 = 'src/main/java/com/galvanize/crudSample/domain/Employee.java';

async function reset() {
  for (let i = 1; i <= 59; i++) {
  await git.init()
  .then(() => console.log(`Adding branch to repo # ${i}`))
  .then(() => git.removeRemote('origin'))
  .then(() => console.log("origin removed"))
  .then(() => git.addRemote('origin', `https://code.il2.dso.mil/tron/products/workshops/workshop-apps/p1-workshop-java-${i < 10 ? `0${i}` : i}`))
  .then(() => console.log("origin added"))
  .then(() => git.fetch('origin', 'master'))
  .then(() => console.log("fetched"))
  .then(() => git.checkout('master'))
  .then(() => git.raw(['reset', '--hard', 'origin/master']))
  .then(() => console.log('Reset to remote'))
  .then(() => git.raw('branch', '-D', 'employee2'))
  .then(() => git.raw('checkout', '-b', 'employee2'))
  .then(() => console.log("Creating new employee2 branch"))
  .then(() => fs.copyFile(oldPath, newPath, (err) => {
    if (err) throw err
    console.log('Successfully moved EmployeeDaoMapImpl.java')
  }))
  .then(() => fs.copyFile(oldPath2, newPath2, (err) => {
    if (err) throw err
    console.log('Successfully moved Employee.java')
  }))
  .then(() => git.raw('commit', `${newPath}`, '-m "Adding EmployeeDaoMapImpl.java'))
  .then(() => git.raw('commit', `${newPath2}`, '-m "Adding Employee.java"'))
  .then(() => console.log("Committing and pushing new files"))
  .then(() => git.raw(['push', '--force', 'origin', 'employee2',]))
  .then(() => console.log(`Workshop # ${i} now has employee2 branch`))
  .catch(err => console.error(err))
  }
}

console.log("Preparing to create/reset employee2 branch");
// git.raw('checkout', '-b', 'employee2'); // Setup, first time only
reset();
