# Galvanize - Spring Starter

## For most SpringBoot projects (made from [Spring Initializr](https://start.spring.io/)) you can from CLI:

1) ```./gradlew bootRun``` to run server

2) `./gradlew test` to run the test suite 

---
Example requests/endpoints:

|Method | URL | Response |
|------|------|------|
|HTTP GET | http://localhost:8080/ | Homepage |
|HTTP GET | http://localhost:8080/ws60-api/employee/{id} | {"id":int,"name":string,"age":int,"salary":double} |

---