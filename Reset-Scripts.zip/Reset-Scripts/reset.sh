#!/bin/bash

echo "BEGINNING RESET PROCESS..."
./resetUnprotect.sh
echo "STEP 1: COMPLETE - BRANCHES UNPROTECTED"
node resetAll.js
echo "STEP 2: COMPLETE - MASTER BRANCH RESET"
node resetEmp.js
echo "STEP 3: COMPLETE - EMPLOYEE2 BRANCH RESET"
./resetBranches.sh
node resetBranchExp.js
echo "STEP 4: COMPLETE - DELETED OTHER BRANCHES"
./resetProtect.sh
echo "STEP 5: COMPLETE - BRANCHES PROTECTED"
echo "COMPLETE: ALL REPOS READY"
