package com.galvanize.crudSample.domain;

import java.util.Objects;
import java.util.Random;

public class Employee {
    long id;
    String name;
    int age;
    double salary;

    public static final Employee SAMPLE_EMPLOYEE = new Employee(1,"Bob", 25, 25000.0);
    public static final Employee SAMPLE_EMPLOYEE_2 = new Employee(2,"Mary", 30, 35000.0);


    private Employee(long id, String name, int age, double salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;
        this.id = id;
    }

    public Employee(String name, int age, double salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;
        generateId();
    }

    public Employee() {
        generateId();
    }

    private void generateId() {
        id = new Random().nextLong();
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employee employee = (Employee) o;
        return age == employee.age &&
                Double.compare(employee.salary, salary) == 0 &&
                Objects.equals(name, employee.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, age, salary);
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", salary=" + salary +
                '}';
    }
}
