const simpleGit = require("simple-git");
const git = simpleGit();

console.log('Preparing to reset master...');

const commitArr = [
  "filler",
  "096f86a6a7626f5bc6b56b14cf1adc9f8578b186",
  "3161807e1c5ba3fe106d2aedafb2a30a271407fd",
  "036c8d533b3b7e6b767154ebddbe5a34f567f152",
  "5807a834259b7cd6769bbecd787206ad41b0d568",
  "38d9321a6a06fff02c1cd990dc024b7a7a7ee3fe", // 5
  "9f0d487049575cb45aaa601a98889a1300bc7a68",
  "479697ab3345851ea7b4b38adc360fd9594f252a",
  "444d64c993af99b08d249ea3934dda43b8cb387b",
  "bcc489f54326e4bbda1c0fd6f2242948456ab6f2",
  "4381f659b151c95f37726745c908d729712f10cc", // 10
  "e9193d02f421289bbb987b1a3be703eee788fd7a",
  "234244a9cb2a947b7a539a3ce712c803ee342a1e",
  "e06e001abd1877458b65d8229a797306c9a14db5",
  "ffe1b757d21ae6a025dcdd5d82ed323cb0390ece",
  "edea2459b860b4ebd86ab6d52cd4be9f733f4b83", // 15
  "f9808912e3ce5a378982d56f0a40df212a828fed", //
  "8c05bfe529e9bf7d23cdb0d2656340128e7fc6d4",
  "7ccedfc9b7b754317948e375a367fd5911c145f9",
  "0aefca9736876ade92161c47c1cc79667d62e4c3",
  "458a24357ae23146e8d882648b3c8815b0437280", // 20
  "65e6cf89894e6e5096621f879bf066fbf5853c4a",
  "5fc3650dbdcfe8dddca76f9d5dd0bde06391bf60",
  "d38d4e3e5744aa28281bbfbf21962327f9d97a3e",
  "5b691742a6c578858e292e25e3ecd60eab1149b0",
  "479520d8edf0593a7edd6855939dc0d05b7d9b2c", // 25
  "4b8d7c1f0b6e49b1e629824925035a5e2c4efdf0",
  "547bd22a602ead1df7bcf77ad32f882360b91139",
  "0047c8cdd14e4d912d45f552f88e00b8a5a480ee",
  "921fec10f019f804f60f36f5a832df4a82114dd5",
  "af4982d73eba8631afca58ede5357f712b6e3418", // 30
  "5c7e38f3ae6396964c95d5400231b8dd11067253",
  "62411320d1064d2db737bae0ee3a4fca3296b470",
  "1c5036d28d834e93b73f1da8712b0b1e00cecc33",
  "6207f410fc203e2e0692d15c9f8328f1d560ba95",
  "3cfab57f28495bd32ff7fbfa13dc0beb11e573a1", // 35
  "bc48acefbbe6ad1939c24e6cab4c017c73ee7472",
  "7192a0177eeca40343f7ea18c198a5f2cba9795b",
  "54ea6a8bb991bafa3c20822174f044eb1a4ac2a1",
  "e4f509e2e3a1a32aee20fb112bec00e3ef73e946",
  "fad82e02325c2a9bf0d982e51eff56a044760185", // 40
  "dfdb7232a74ef813647a4d1193e0fad760cb8c4f",
  "9a3c5eddc76d15725155e50477cda4f6b6966153",
  "1ca262606f37c43226cff5225f283b23ecda5d0b",
  "7bd6c75aa3f9810419f8d1e9f523a207730f39a2",
  "ce02882cd88d50ee4043d31c5928cb55a9f7a416", // 45
  "8d4cd3c9775d8c017f0ac8af4508e8bc25488f13",
  "f50948922077b0d281e9bfa8942d825d2db502dd",
  "55d763018631588313fb5442704994fe0bef71eb",
  "f07429843cff935d593b0db4ec82b8711d8fb6f7",
  "7ee33d3e9b276f3edf4ae4ed0b2f274e1d7d9803", // 50
  "a4eb033c76a4a1334a50a8ef21d9c660c81bccb5",
  "8dafb89a12f040a28f350212b861848d23c7336f",
  "5291ad89a793b6f8a3cc36795099b814398017bb",
  "368761f046a84cdf4c74389c2468e75dcc10822a",
  "2279ec0fc0be12b6da2f2cb576a1374e5989f1de", // 55
  "a1123201d71bb03a685aa52409e5760f8419eb4f",
  "8687a6e6471c3ceddb4f17b21c16f19fff39eb6b",
  "aae0ebc5d1a1db50ce7a93e9a0a3e9975018920d",
  "f005afae758f945b0a365e6c74e7255012346b71",
  "f5469700b856e50b9deeec209d70da4066670c9a"
]


async function reset() {
  for (let i = 1; i <= 60; i++) {
  await git.init()
  .then(() => console.log(`Resetting repo # ${i}`))
  .then(() => git.removeRemote('origin'))
  .then(() => console.log("origin removed"))
  .then(() => git.addRemote('origin', `https://code.il2.dso.mil/tron/products/workshops/workshop-apps/p1-workshop-java-${i < 10 ? `0${i}` : i}`))
  .then(() => console.log("origin added"))
  .then(() => git.fetch('origin', 'master'))
  .then(() => console.log("fetched"))
  .then(() => git.checkout('master'))
  .then(() => console.log("checked out master"))
  .then(() => git.raw(['reset', '--hard', commitArr[i]]))
  .then(() => console.log(`reset to ${commitArr[i]}`))
  .then(() => git.raw(['push', '--force', 'origin', 'HEAD',]))
  .then(() => console.log(`Workshop # ${i} updated`))
  .catch(err => console.error(err))
  }
}

reset();
