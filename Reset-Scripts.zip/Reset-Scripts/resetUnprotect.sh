#!/bin/bash

token=YOUR_KEY_HERE

for ((i=285;i<=314;i++)); do
# # curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/master?private_token=${token}";
# # curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/employee2?private_token=${token}";
# # curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/feature%2F%2A?private_token=${token}";
# # curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/feature%2Fadd-manager?private_token=${token}";
curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/%2A?private_token=${token}";
done

echo "Unprotected 1-30"

for ((i=452;i<=481;i++)); do
# curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/master?private_token=${token}";
# curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/employee2?private_token=${token}";
# curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/feature%2F%2A?private_token=${token}";
# curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/feature%2Fadd-manager?private_token=${token}";
curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches/%2A?private_token=${token}";
done

echo "Unprotected 30-60"

