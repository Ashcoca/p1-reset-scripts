package com.galvanize.crudSample.controller;

import com.galvanize.crudSample.dao.EmployeeDao;
import com.galvanize.crudSample.domain.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeDao dao;

    @GetMapping("/ws60-api/employee/{id}")
    public Employee getEmployeeById(@PathVariable Long id) {
        Employee e = dao.getEmployee(id);
        return e;
    }

}
