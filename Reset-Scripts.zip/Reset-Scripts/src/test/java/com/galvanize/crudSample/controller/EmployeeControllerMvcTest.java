package com.galvanize.crudSample.controller;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@SpringBootTest
@AutoConfigureMockMvc

public class EmployeeControllerMvcTest {

    @Autowired
    private MockMvc mvc;

    @Test
    @DisplayName("Get /ws60-api/employee/1")
    public void testThatGetEmployee1ReturnsCorrectJson() throws Exception {
        ResultActions actions = mvc.perform(get("/ws60-api/employee/1"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))

                .andExpect(jsonPath("$.*", hasSize(4)))

                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.name", is("Bob")))
                .andExpect(jsonPath("$.age", is(25)))
                .andExpect(jsonPath("$.salary", is(25000.0)))

                ; // end expectations
    }
}