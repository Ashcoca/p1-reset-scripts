package com.galvanize.crudSample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
