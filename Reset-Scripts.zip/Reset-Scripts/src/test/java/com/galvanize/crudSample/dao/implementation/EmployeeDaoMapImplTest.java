package com.galvanize.crudSample.dao.implementation;

import com.galvanize.crudSample.dao.EmployeeDao;
import com.galvanize.crudSample.domain.Employee;
import com.galvanize.crudSample.exception.DataException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class EmployeeDaoMapImplTest {

    EmployeeDao dao;
    Employee fred;


    @BeforeEach
    public void setUp() {
        dao = new EmployeeDaoMapImpl();
        fred = new Employee("Fred", 30, 30000.0);
    }

    @AfterEach
    public void tearDown() {
        dao = null;
        fred = null;
    }


    @Test
    public void testThatConstructorWorks() {
        Employee e = dao.getEmployee(1);
        assertEquals(Employee.SAMPLE_EMPLOYEE, e);
    }

    @Test
    public void testThatGetEmployeeReturnsNullWhenNoEmployeeFound() {
        Employee e = dao.getEmployee(3);
        assertNull(e);
    }

    @Test
    public void testThatAddEmployeeWorks() {
        Employee fromDao = null;
        long id = fred.getId();
        try {
            dao.addEmployee(fred);
            fromDao = dao.getEmployee(id);
        } catch (DataException dataException) {
            fail();
        }
        assertEquals(fred, fromDao);
    }

    @Test
    public void testThatUpdateEmployeeWorks() throws DataException {
        dao.addEmployee(fred);
        assertEquals(fred, dao.getEmployee(fred.getId()));
    }

    @Test
    public void testThatRemoveEmployeeWorks() throws DataException {
        dao.deleteEmployee(Employee.SAMPLE_EMPLOYEE);
        assertNull(dao.getEmployee(1L));
    }

    @Test
    public void testThatFindEmployeeByNameWorks() throws DataException {
        dao.addEmployee(fred);
        List<Employee> employees = dao.getEmployeeByName("Bob");
        assertTrue(1 <= employees.size());
        assertEquals(employees.get(0), Employee.SAMPLE_EMPLOYEE);
    }

    @Test
    public void testThatFindAllEmployeesWorks() throws DataException {
        dao.addEmployee(fred);
        List<Employee> employees = dao.getAllEmployees();
        assertTrue(2 <= employees.size());
        assertTrue( employees.contains(Employee.SAMPLE_EMPLOYEE));
        assertTrue( employees.contains(fred));
    }

    @Test
    public void testThatAddEmployeeFailsWithDuplicateId() {
        assertThrows(DataException.class, () -> {
            dao.addEmployee(Employee.SAMPLE_EMPLOYEE);
        });
    }

    @Test
    public void testThatUpdateEmployeeFailsWithoutEmployeeExisting() {
        assertThrows(DataException.class, () -> {
            dao.updateEmployee(fred);
        });
    }

    @Test
    public void testThatDeleteEmployeeFailsWithMissingDeletee() {
        assertThrows(DataException.class, () -> {
            dao.deleteEmployee(fred);
        });
    }

}
