#!/bin/bash

token=YOUR_KEY_HERE

for ((i=285;i<=314;i++)); do
curl --request POST "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches?private_token=${token}&name=%2A&push_access_level=30&merge_access_level=30&unprotect_access_level=30";
done

echo "Protected 1-30"

for ((i=452;i<=481;i++)); do
curl --request POST "https://code.il2.dso.mil/api/v4/projects/${i}/protected_branches?private_token=${token}&name=%2A&push_access_level=30&merge_access_level=30&unprotect_access_level=30";
done

echo "Protected 31-60"
