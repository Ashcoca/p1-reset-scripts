const fetch = require("node-fetch");

const token = "YOUR_KEY_HERE"

console.log("Preparing to remove all other branches...")

for (let i = 285; i <= 481; i++) {
  if (i > 314 && i < 452) {
    continue;
  }
  let url = `https://code.il2.dso.mil/api/v4/projects/${i}/repository/branches?private_token=${token}`;
  fetch(url, { method: "GET" })
  .then((res) => res.json())
  .then((responseData) => responseData.map(branch => {
    if (branch.name !== "master" && branch.name !== "employee2") {
      // let encodedBranch = branch.name.replace(/\//g, "%2F")
      // console.log(`Project: ${i} -- ${encodedBranch}`)
      fetch(`https://code.il2.dso.mil/api/v4/projects/${i}/repository/branches/${branch.name}?private_token=${token}`, { method: "DELETE" })
        .then((res) => console.log(`Project ${i} -- ${branch.name} : DELETED`))
        .catch(err => console.error(err)
      )
    }
  }))
};

