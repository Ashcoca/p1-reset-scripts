#!/bin/bash

token=YOUR_KEY_HERE

for ((i=285;i<=314;i++)); do
curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/repository/merged_branches?private_token=${token}";
curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/repository/branches/feature%2Fadd-manager?private_token=${token}";

done

echo "Removed Branches: 1-30"

for ((i=452;i<=481;i++)); do
curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/repository/merged_branches?private_token=${token}";
curl --request DELETE "https://code.il2.dso.mil/api/v4/projects/${i}/repository/branches/feature%2Fadd-manager?private_token=${token}";

done

echo "Removed Branches: 31-60"

