#!/bin/bash

echo "test successful"
